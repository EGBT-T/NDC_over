﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDC_over
{
    class CapitalReply
    {
        Form1 Main;

        public CapitalReply()
        {
            Main = new Form1();
        }

        public void Msg()
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using SKCOMLib;
using HtmlAgilityPack;
using Microsoft.Office.Interop.Outlook;

namespace NDC_over
{
    public partial class Form1 : Form
    {
        SKCenterLib LogIn;
        SKQuoteLib Qoute;
        SKReplyLib ReplyClean;

        CapitalReply Testa;

        string Log_ID = "";

        public string get_ID
        {
            get { return Log_ID; }
            set { Log_ID = value; }
        }

        public Form1()
        {
            Testa = new CapitalReply();

            LogIn = new SKCenterLib();
            Qoute = new SKQuoteLib();
            ReplyClean = new SKReplyLib();

            InitializeComponent();
        }

        private void Log_btn_Click(object sender, EventArgs e)
        {
            if (Virtual_chk.Checked)
                LogIn.SKCenterLib_ResetServer("morder1.capital.com.tw");

            int Log_code = LogIn.SKCenterLib_Login(Account_txt.Text.Trim().ToUpper(), Password_txt.Text.Trim());

            if (Log_code == 0)
            {
                this.get_ID = Account_txt.Text.Trim().ToUpper();
            }
        }
    }
}
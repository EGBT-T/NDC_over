﻿namespace NDC_over
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.Sign_grp = new System.Windows.Forms.GroupBox();
            this.Account_lbl = new System.Windows.Forms.Label();
            this.Password_lbl = new System.Windows.Forms.Label();
            this.Account_txt = new System.Windows.Forms.TextBox();
            this.Password_txt = new System.Windows.Forms.TextBox();
            this.Remember_chk = new System.Windows.Forms.CheckBox();
            this.Log_btn = new System.Windows.Forms.Button();
            this.Virtual_chk = new System.Windows.Forms.CheckBox();
            this.Client_grp = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.Mail_grp = new System.Windows.Forms.GroupBox();
            this.Title_lbl = new System.Windows.Forms.Label();
            this.Content_lbl = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.Sign_grp.SuspendLayout();
            this.Client_grp.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.Mail_grp.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(-1, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(877, 520);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.Sign_grp);
            this.tabPage1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(869, 494);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Basis setting";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Client_grp);
            this.tabPage2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(869, 494);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Client setting";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.Mail_grp);
            this.tabPage3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(869, 494);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Mail setting";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // Sign_grp
            // 
            this.Sign_grp.Controls.Add(this.Virtual_chk);
            this.Sign_grp.Controls.Add(this.Log_btn);
            this.Sign_grp.Controls.Add(this.Remember_chk);
            this.Sign_grp.Controls.Add(this.Password_txt);
            this.Sign_grp.Controls.Add(this.Account_txt);
            this.Sign_grp.Controls.Add(this.Password_lbl);
            this.Sign_grp.Controls.Add(this.Account_lbl);
            this.Sign_grp.Location = new System.Drawing.Point(9, 6);
            this.Sign_grp.Name = "Sign_grp";
            this.Sign_grp.Size = new System.Drawing.Size(451, 81);
            this.Sign_grp.TabIndex = 0;
            this.Sign_grp.TabStop = false;
            this.Sign_grp.Text = "Sing in ( Capital )";
            // 
            // Account_lbl
            // 
            this.Account_lbl.AutoSize = true;
            this.Account_lbl.Location = new System.Drawing.Point(6, 29);
            this.Account_lbl.Name = "Account_lbl";
            this.Account_lbl.Size = new System.Drawing.Size(79, 16);
            this.Account_lbl.TabIndex = 0;
            this.Account_lbl.Text = "Account：";
            // 
            // Password_lbl
            // 
            this.Password_lbl.AutoSize = true;
            this.Password_lbl.Location = new System.Drawing.Point(187, 29);
            this.Password_lbl.Name = "Password_lbl";
            this.Password_lbl.Size = new System.Drawing.Size(86, 16);
            this.Password_lbl.TabIndex = 1;
            this.Password_lbl.Text = "Password：";
            // 
            // Account_txt
            // 
            this.Account_txt.Location = new System.Drawing.Point(81, 26);
            this.Account_txt.Name = "Account_txt";
            this.Account_txt.Size = new System.Drawing.Size(100, 23);
            this.Account_txt.TabIndex = 2;
            this.Account_txt.Text = "R124207177";
            this.Account_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Password_txt
            // 
            this.Password_txt.Location = new System.Drawing.Point(270, 26);
            this.Password_txt.Name = "Password_txt";
            this.Password_txt.PasswordChar = '*';
            this.Password_txt.Size = new System.Drawing.Size(100, 23);
            this.Password_txt.TabIndex = 3;
            this.Password_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Remember_chk
            // 
            this.Remember_chk.AutoSize = true;
            this.Remember_chk.Location = new System.Drawing.Point(190, 55);
            this.Remember_chk.Name = "Remember_chk";
            this.Remember_chk.Size = new System.Drawing.Size(94, 20);
            this.Remember_chk.TabIndex = 4;
            this.Remember_chk.Text = "Remember";
            this.Remember_chk.UseVisualStyleBackColor = true;
            // 
            // Log_btn
            // 
            this.Log_btn.Location = new System.Drawing.Point(376, 21);
            this.Log_btn.Name = "Log_btn";
            this.Log_btn.Size = new System.Drawing.Size(68, 33);
            this.Log_btn.TabIndex = 5;
            this.Log_btn.Text = "Sign";
            this.Log_btn.UseVisualStyleBackColor = true;
            this.Log_btn.Click += new System.EventHandler(this.Log_btn_Click);
            // 
            // Virtual_chk
            // 
            this.Virtual_chk.AutoSize = true;
            this.Virtual_chk.Location = new System.Drawing.Point(301, 55);
            this.Virtual_chk.Name = "Virtual_chk";
            this.Virtual_chk.Size = new System.Drawing.Size(69, 20);
            this.Virtual_chk.TabIndex = 6;
            this.Virtual_chk.Text = "Virtual";
            this.Virtual_chk.UseVisualStyleBackColor = true;
            // 
            // Client_grp
            // 
            this.Client_grp.Controls.Add(this.groupBox3);
            this.Client_grp.Location = new System.Drawing.Point(10, 7);
            this.Client_grp.Name = "Client_grp";
            this.Client_grp.Size = new System.Drawing.Size(466, 481);
            this.Client_grp.TabIndex = 0;
            this.Client_grp.TabStop = false;
            this.Client_grp.Text = "Client";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(333, 48);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Confirm";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Location = new System.Drawing.Point(6, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(444, 81);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(6, 22);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(92, 20);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Add client";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(218, 22);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(109, 20);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Delete client";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(6, 48);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(321, 23);
            this.textBox3.TabIndex = 2;
            this.textBox3.Text = "yhn75920002000@yahoo.com.tw";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Mail_grp
            // 
            this.Mail_grp.Controls.Add(this.textBox4);
            this.Mail_grp.Controls.Add(this.Content_lbl);
            this.Mail_grp.Controls.Add(this.Title_lbl);
            this.Mail_grp.Location = new System.Drawing.Point(30, 47);
            this.Mail_grp.Name = "Mail_grp";
            this.Mail_grp.Size = new System.Drawing.Size(575, 384);
            this.Mail_grp.TabIndex = 0;
            this.Mail_grp.TabStop = false;
            this.Mail_grp.Text = "Mail";
            // 
            // Title_lbl
            // 
            this.Title_lbl.AutoSize = true;
            this.Title_lbl.Location = new System.Drawing.Point(38, 37);
            this.Title_lbl.Name = "Title_lbl";
            this.Title_lbl.Size = new System.Drawing.Size(53, 16);
            this.Title_lbl.TabIndex = 0;
            this.Title_lbl.Text = "Title：";
            // 
            // Content_lbl
            // 
            this.Content_lbl.AutoSize = true;
            this.Content_lbl.Location = new System.Drawing.Point(41, 66);
            this.Content_lbl.Name = "Content_lbl";
            this.Content_lbl.Size = new System.Drawing.Size(77, 16);
            this.Content_lbl.TabIndex = 1;
            this.Content_lbl.Text = "Content：";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(107, 34);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 23);
            this.textBox4.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(975, 534);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NDC_over";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.Sign_grp.ResumeLayout(false);
            this.Sign_grp.PerformLayout();
            this.Client_grp.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.Mail_grp.ResumeLayout(false);
            this.Mail_grp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox Sign_grp;
        private System.Windows.Forms.CheckBox Virtual_chk;
        private System.Windows.Forms.Button Log_btn;
        private System.Windows.Forms.CheckBox Remember_chk;
        private System.Windows.Forms.TextBox Password_txt;
        private System.Windows.Forms.TextBox Account_txt;
        private System.Windows.Forms.Label Password_lbl;
        private System.Windows.Forms.Label Account_lbl;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox Client_grp;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox Mail_grp;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label Content_lbl;
        private System.Windows.Forms.Label Title_lbl;
    }
}


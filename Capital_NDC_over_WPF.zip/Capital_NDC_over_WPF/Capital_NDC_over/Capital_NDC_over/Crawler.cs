﻿using System;
using System.Text;

using Microsoft.Office.Interop.Outlook;
using HtmlAgilityPack;
using System.Net;
using System.IO;

namespace Capital_NDC_over
{
    class Crawler
    {
        ApplicationClass AppClass = new ApplicationClass();
        HtmlDocument Html = new HtmlDocument();
        HtmlNodeCollection Nodes;

        public void Crawler_Email()
        {
            NameSpace OutlookNS = AppClass.GetNamespace("MAPI");
            MAPIFolder InboxFolder = OutlookNS.GetDefaultFolder(OlDefaultFolders.olFolderInbox);

            foreach (object OBJ in InboxFolder.Items)
            {
                MailItem Item = OBJ as MailItem;
                if (Item != null)
                {
                    if (Item.Subject == "盤後多空比 " + DateTime.Now.ToString("M/d"))
                    {
                        Html.LoadHtml(Item.HTMLBody);
                        Nodes = Html.DocumentNode.SelectNodes("//table[@class='content'][1]/tr[4]/td");
                        System.Windows.MessageBox.Show("=> " + Nodes[Nodes.Count - 3].InnerText + " <==> " + Nodes[Nodes.Count - 2].InnerText);
                    }
                }
            }
        }

        public void Crawler_MarketInfo()
        {
            string URL = GetHttptxt("http://www.taifex.com.tw/chinese/3/7_12_3.asp");
            Html.LoadHtml(URL);
            //System.Windows.MessageBox.Show(Html.ToString());
            System.Windows.MessageBox.Show(Html.DocumentNode.InnerHtml.ToString());
            //Nodes = Html.DocumentNode.SelectNodes("");
        }

        public static string GetHttptxt(string StrURL)
        {
            //Uri UrlCheck = new Uri(StrURL);
            //WebRequest Request = WebRequest.Create(UrlCheck);
            //Stream St = HttpWebRequest.Create(StrURL).GetResponse().GetResponseStream();
            return new StreamReader(HttpWebRequest.Create(StrURL).GetResponse().GetResponseStream(), Encoding.GetEncoding("UTF-8")).ReadToEnd();
        }
    }
}

﻿using System;
using System.Text;

using Microsoft.Office.Interop.Outlook;
using HtmlAgilityPack;
using System.Net;
using System.IO;

namespace Capital_NDC_over
{
    class Crawler
    {
        ApplicationClass AppClass = new ApplicationClass();
        HtmlDocument Html = new HtmlDocument();
        HtmlNodeCollection Nodes;

        void Crawler_Email()
        {
            NameSpace OutlookNS = AppClass.GetNamespace("MAPI");
            MAPIFolder InboxFolder = OutlookNS.GetDefaultFolder(OlDefaultFolders.olFolderInbox);

            foreach (object OBJ in InboxFolder.Items)
            {
                MailItem Item = OBJ as MailItem;
                if (Item != null)
                {
                    Html.LoadHtml(Item.HTMLBody);
                    Nodes = Html.DocumentNode.SelectNodes("//table[@class='content'][1]/tr[3]/td");
                }
            }
        }

        void Crawler_MarketInfo()
        {
            string URL = GetHttptxt("");
            Html.LoadHtml(URL);
            Nodes = Html.DocumentNode.SelectNodes("");
        }

        public static string GetHttptxt(string StrURL)
        {
            Uri UrlCheck = new Uri(StrURL);
            WebRequest Request = WebRequest.Create(UrlCheck);
            //Stream St = HttpWebRequest.Create(StrURL).GetResponse().GetResponseStream();
            return new StreamReader(HttpWebRequest.Create(StrURL).GetResponse().GetResponseStream(), Encoding.GetEncoding("UTF-8")).ReadToEnd();
        }
    }
}

﻿using System;
using System.Windows;
using System.Windows.Threading;

using SKCOMLib;
using Microsoft.Office.Interop.Outlook;
using HtmlAgilityPack;

namespace Capital_NDC_over
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        SKCenterLib Log;
        SKQuoteLib Quote;
        SKReplyLib Reply;

        string Sign_ID = "";

        string Get_ID
        {
            get { return Sign_ID; }
            set { Sign_ID = value; }
        }

        public MainWindow()
        {
            Log = new SKCenterLib();
            Quote = new SKQuoteLib();
            Reply = new SKReplyLib();

            ///------------------------------------///
            /// Create _Time object. Register event///
            ///------------------------------------///
            DispatcherTimer _Time = new DispatcherTimer();
            _Time.Interval = TimeSpan.FromMilliseconds(1000);
            _Time.Tick += _Time_tick;
            _Time.Start();

            InitializeComponent();
        }

        void _Time_tick(object sender, EventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Virtual_chk.IsChecked.Value)
                Log.SKCenterLib_ResetServer("morder1.capital.com.tw");
                

            int Sign_code = Log.SKCenterLib_Login(Account_txt.Text.Trim().ToUpper(), Password_box.Password.Trim());
            if (Sign_code == 0)
                this.Get_ID = Account_txt.Text.Trim().ToUpper();
                MessageBox.Show(Sign_code.ToString());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Crawler Crr = new Crawler();
            Crr.Crawler_Email();
        }
    }
}

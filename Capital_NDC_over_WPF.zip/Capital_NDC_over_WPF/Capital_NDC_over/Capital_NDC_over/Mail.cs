﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Outlook = Microsoft.Office.Interop.Outlook;

namespace Capital_NDC_over
{
    class Mail
    {
        

        void Send_email()
        {
            Microsoft.Office.Interop.Outlook.Application olapp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.MailItem msg = (Microsoft.Office.Interop.Outlook.MailItem)olapp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
            string body = "";

            msg.Subject = "new message";
            msg.To = "xxxx@yyy.com";
            body = "test msg";
            msg.BodyFormat = Microsoft.Office.Interop.Outlook.OlBodyFormat.olFormatHTML;
            msg.HTMLBody = body;
            msg.Display();
            msg.Send();


        }
    }
}
